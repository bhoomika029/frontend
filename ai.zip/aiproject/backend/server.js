// Load environment variables FIRST
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = process.env.PORT || 5000;

// Debug: Check if API key is loaded
console.log('🔑 Gemini API Key Status:', process.env.GEMINI_API_KEY ? '✓ Loaded' : '✗ Missing');

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// UPDATED MODEL LIST - Use gemini-2.5 models that work
const MODELS_TO_TRY = [
  'gemini-2.5-flash',
  'gemini-2.5-pro',
  'gemini-1.5-flash',
  'gemini-pro'
];

// Recipe generation endpoint
app.post('/api/generate-recipe', async (req, res) => {
  try {
    const { ingredients, cuisine, dietaryRestrictions, cookingTime, servings } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(401).json({
        success: false,
        error: 'API Key Missing. Please set the GEMINI_API_KEY in your .env file.',
      });
    }

    const prompt = `You are a professional chef. Create a detailed recipe with these requirements:

Ingredients available: ${ingredients}
Cuisine type: ${cuisine || 'Any'}
Dietary restrictions: ${dietaryRestrictions || 'None'}
Cooking time: ${cookingTime || 'Any'} minutes
Servings: ${servings || 2}

Please provide:
1. Recipe Name (as a heading)
2. Brief Description
3. Ingredients List with measurements
4. Step-by-step Cooking Instructions (numbered)
5. Total Cooking Time
6. Nutritional Information per serving (Estimate)
7. Serving Suggestions

Make it detailed and easy to follow.`;

    console.log('🤖 Generating recipe with Gemini AI...');

    // Try models in order until one works
    let recipe = null;
    let lastError = null;

    for (const modelName of MODELS_TO_TRY) {
      try {
        console.log(`Trying model: ${modelName}...`);

        // Get the model instance
        const model = genAI.getGenerativeModel({
          model: modelName,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          }
        });

        // Generate the content
        const result = await model.generateContent(prompt);
        const response = result.response;
        recipe = response.text(); // IMPORTANT: Call text() as a function

        console.log(`✅ Success with model: ${modelName}`);
        break; // Success! Exit the loop

      } catch (error) {
        console.log(`❌ Model ${modelName} failed:`, error.message);
        lastError = error;
        continue; // Try next model
      }
    }

    if (recipe) {
      console.log('✅ Recipe generated successfully!');
      res.json({
        success: true,
        recipe: recipe,
      });
    } else {
      throw lastError || new Error('All configured models failed to generate content.');
    }

  } catch (error) {
    console.error('❌ Error generating recipe:', error.message);

    // Detailed error handling
    if (!process.env.GEMINI_API_KEY || (error.message && error.message.includes('API key'))) {
      return res.status(401).json({
        success: false,
        error: 'Authentication Error: Invalid or missing API key.',
      });
    }

    if (error.message && error.message.includes('quota')) {
      return res.status(429).json({
        success: false,
        error: 'API quota exceeded. Please try again later.',
      });
    }

    if (error.message && (error.message.includes('not found') || error.message.includes('404'))) {
      return res.status(404).json({
        success: false,
        error: 'Model Not Found: Please check if your API key has access to Gemini models.',
      });
    }

    res.status(500).json({
      success: false,
      error: `Failed to generate recipe: ${error.message}`,
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'Server is running',
    aiService: 'Google Gemini AI',
    apiKeyLoaded: !!process.env.GEMINI_API_KEY
  });
});

// Test endpoint to check which models work
app.get('/api/test-models', async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(401).json({ results: [], error: 'API Key Missing' });
  }

  const results = [];

  for (const modelName of MODELS_TO_TRY) {
    try {
      const model = genAI.getGenerativeModel({ model: modelName });
      const result = await model.generateContent("Say hello");
      results.push({ model: modelName, status: 'works', response: result.response.text() });
    } catch (error) {
      results.push({ model: modelName, status: 'failed', error: error.message });
    }
  }

  res.json({ results });
});

app.listen(port, () => {
  console.log(`✓ Server is running on port ${port}`);
  console.log(`✓ AI Service: Google Gemini`);
  console.log(`✓ Test models: http://localhost:${port}/api/test-models`);
});