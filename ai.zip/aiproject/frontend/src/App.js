import React, { useState } from 'react';
import RecipeForm from './components/RecipeForm';
import RecipeDisplay from './components/RecipeDisplay';
import './App.css';

function App() {
  const [recipe, setRecipe] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateRecipe = async (formData) => {
    setLoading(true);
    setError('');
    setRecipe('');

    try {
      console.log('🚀 Sending request:', formData);
      const response = await fetch('http://localhost:5000/api/generate-recipe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      console.log('📡 Response status:', response.status);
      const data = await response.json();
      console.log('📦 Response data:', data);

      if (data.success) {
        console.log('✅ Recipe received, length:', data.recipe.length);
        console.log('📝 First 100 chars:', data.recipe.substring(0, 100));
        setRecipe(data.recipe);
        console.log('✅ Recipe state updated');
      } else {
        console.log('❌ API returned success=false');
        setError(data.error || 'Failed to generate recipe');
      }
    } catch (err) {
      console.error('❌ Catch block error:', err);
      setError('Network error. Please check if the server is running.');
    } finally {
      setLoading(false);
      console.log('🏁 Loading set to false');
    }
  };

  console.log('🎨 Rendering App, recipe length:', recipe.length, 'loading:', loading);

  return (
    <div className="App">
      <header className="App-header">
        <h1>🍳 AI Recipe Generator</h1>
        <p>Generate personalized recipes with AI</p>
      </header>

      <main className="App-main">
        <RecipeForm onGenerateRecipe={handleGenerateRecipe} loading={loading} />
        
        {error && (
          <div className="error-message">
            <p>{error}</p>
          </div>
        )}

        {loading && (
          <div className="loading">
            <div className="spinner"></div>
            <p>Generating your recipe...</p>
          </div>
        )}

        {recipe && !loading && (
          <RecipeDisplay recipe={recipe} />
        )}
      </main>

      <footer className="App-footer">
        <p>Powered by Google Gemini AI</p>
      </footer>
    </div>
  );
}

export default App;