import React from 'react';
import './RecipeDisplay.css';

function RecipeDisplay({ recipe }) {
  return (
    <div className="recipe-display">
      <div className="recipe-content">
        <div className="recipe-header">
          <h2>Your Recipe</h2>
          <button 
            className="print-btn"
            onClick={() => window.print()}
          >
            🖨️ Print
          </button>
        </div>
        <div className="recipe-text">
          {recipe.split('\n').map((line, index) => (
            <p key={index}>{line}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

export default RecipeDisplay;