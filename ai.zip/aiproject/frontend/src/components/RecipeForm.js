import React, { useState } from 'react';
import './RecipeForm.css';

function RecipeForm({ onGenerateRecipe, loading }) {
  const [formData, setFormData] = useState({
    ingredients: '',
    cuisine: '',
    dietaryRestrictions: '',
    cookingTime: '',
    servings: '2',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.ingredients.trim()) {
      onGenerateRecipe(formData);
    }
  };

  return (
    <form className="recipe-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="ingredients">
          Ingredients (comma-separated) *
        </label>
        <textarea
          id="ingredients"
          name="ingredients"
          value={formData.ingredients}
          onChange={handleChange}
          placeholder="e.g., chicken, tomatoes, garlic, pasta"
          required
          rows="3"
        />
      </div>

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="cuisine">Cuisine Type</label>
          <select
            id="cuisine"
            name="cuisine"
            value={formData.cuisine}
            onChange={handleChange}
          >
            <option value="">Any</option>
            <option value="Italian">Italian</option>
            <option value="Mexican">Mexican</option>
            <option value="Chinese">Chinese</option>
            <option value="Indian">Indian</option>
            <option value="Japanese">Japanese</option>
            <option value="Thai">Thai</option>
            <option value="Mediterranean">Mediterranean</option>
            <option value="American">American</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="servings">Servings</label>
          <input
            type="number"
            id="servings"
            name="servings"
            value={formData.servings}
            onChange={handleChange}
            min="1"
            max="12"
          />
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="cookingTime">Cooking Time (minutes)</label>
          <input
            type="number"
            id="cookingTime"
            name="cookingTime"
            value={formData.cookingTime}
            onChange={handleChange}
            placeholder="e.g., 30"
            min="5"
          />
        </div>

        <div className="form-group">
          <label htmlFor="dietaryRestrictions">Dietary Restrictions</label>
          <select
            id="dietaryRestrictions"
            name="dietaryRestrictions"
            value={formData.dietaryRestrictions}
            onChange={handleChange}
          >
            <option value="">None</option>
            <option value="Vegetarian">Vegetarian</option>
            <option value="Vegan">Vegan</option>
            <option value="Gluten-Free">Gluten-Free</option>
            <option value="Dairy-Free">Dairy-Free</option>
            <option value="Keto">Keto</option>
            <option value="Paleo">Paleo</option>
          </select>
        </div>
      </div>

      <button type="submit" className="generate-btn" disabled={loading}>
        {loading ? 'Generating...' : '🍳 Generate Recipe'}
      </button>
    </form>
  );
}

export default RecipeForm;